public class Driver {
    private int id;
    private String location;
    private boolean isAvailable;

    public Driver(int id, String location) {
        this.id = id;
        this.location = location;
        this.isAvailable = true;
    }

    public int getId() {
        return id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    public void setAvailable(boolean isAvailable) {
        this.isAvailable = isAvailable;
    }
}
