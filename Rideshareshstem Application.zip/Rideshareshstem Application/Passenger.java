public class Passenger {
    private int id;
    private String location;
    private String destination;

    public Passenger(int id, String location, String destination) {
        this.id = id;
        this.location = location;
        this.destination = destination;
    }

    public int getId() {
        return id;
    }

    public String getLocation() {
        return location;
    }

    public String getDestination() {
        return destination;
    }
}
