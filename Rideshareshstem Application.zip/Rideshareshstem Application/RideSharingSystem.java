import java.util.*;

public class RideSharingSystem {
    private Graph graph;
    private Map<Integer, Driver> drivers;
    private Map<Integer, Passenger> passengers;

    public RideSharingSystem() {
        this.graph = new Graph();
        this.drivers = new HashMap<>();
        this.passengers = new HashMap<>();
    }

    public void addDriver(int id, String location) {
        drivers.put(id, new Driver(id, location));
    }

    public void addPassenger(int id, String location, String destination) {
        passengers.put(id, new Passenger(id, location, destination));
    }

    public void addRoad(String start, String end, int travelTime) {
        graph.addEdge(start, end, travelTime);
    }

    public void assignRides() {
        for (Passenger passenger : passengers.values()) {
            Driver bestDriver = null;
            int minTravelTime = Integer.MAX_VALUE;

            for (Driver driver : drivers.values()) {
                if (driver.isAvailable()) {
                    List<String> path = graph.shortestPath(driver.getLocation(), passenger.getLocation());
                    if (!path.isEmpty()) {
                        int travelTime = path.size() - 1;
                        if (travelTime < minTravelTime) {
                            bestDriver = driver;
                            minTravelTime = travelTime;
                        }
                    }
                }
            }

            if (bestDriver != null) {
                System.out.println("Assigned Driver " + bestDriver.getId() + " to Passenger " + passenger.getId());
                bestDriver.setLocation(passenger.getDestination());
                bestDriver.setAvailable(false);
            } else {
                System.out.println("No available driver for Passenger " + passenger.getId());
            }
        }
    }
}
