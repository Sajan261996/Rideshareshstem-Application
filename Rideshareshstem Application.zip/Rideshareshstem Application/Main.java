import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        RideSharingSystem system = new RideSharingSystem();
        Scanner scanner = new Scanner(System.in);

        while (true) {
            // Display the menu
            System.out.println("\nWelcome to Ride Sharing System");
            System.out.println("1. Add Driver");
            System.out.println("2. Add Passenger");
            System.out.println("3. Find Shortest Path");
            System.out.println("4. Assign Rides");
            System.out.println("5. Exit");
            System.out.print("Enter your choice: ");

            int choice = scanner.nextInt();
            scanner.nextLine(); // Consume the newline

            switch (choice) {
                case 1:
                    // Add Driver
                    System.out.print("Enter Driver ID: ");
                    int driverId = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline
                    System.out.print("Enter Driver Location: ");
                    String driverLocation = scanner.nextLine();
                    system.addDriver(driverId, driverLocation);
                    System.out.println("Driver added successfully!");
                    break;

                case 2:
                    // Add Passenger
                    System.out.print("Enter Passenger ID: ");
                    int passengerId = scanner.nextInt();
                    scanner.nextLine(); // Consume the newline
                    System.out.print("Enter Passenger Current Location: ");
                    String passengerLocation = scanner.nextLine();
                    System.out.print("Enter Passenger Destination: ");
                    String passengerDestination = scanner.nextLine();
                    system.addPassenger(passengerId, passengerLocation, passengerDestination);
                    System.out.println("Passenger added successfully!");
                    break;

                case 3:
                    // Find Shortest Path
                    System.out.print("Enter Start Location: ");
                    String startLocation = scanner.nextLine();
                    System.out.print("Enter End Location: ");
                    String endLocation = scanner.nextLine();
                    System.out.println("Finding shortest path...");
                    var path = system.getGraph().shortestPath(startLocation, endLocation);
                    if (path.isEmpty()) {
                        System.out.println("No path found between the given locations.");
                    } else {
                        System.out.println("Shortest Path: " + String.join(" -> ", path));
                    }
                    break;

                case 4:
                    // Assign Rides
                    System.out.println("Assigning rides...");
                    system.assignRides();
                    break;

                case 5:
                    // Exit
                    System.out.println("Exiting the system. Thank you!");
                    scanner.close();
                    System.exit(0);
                    break;

                default:
                    System.out.println("Invalid choice! Please try again.");
            }
        }
    }
}
