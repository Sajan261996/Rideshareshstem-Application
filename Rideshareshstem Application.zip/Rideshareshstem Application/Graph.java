import java.util.*;

public class Graph {
    private Map<String, List<Edge>> adjacencyList;

    public Graph() {
        this.adjacencyList = new HashMap<>();
    }

    public void addEdge(String start, String end, int weight) {
        adjacencyList.putIfAbsent(start, new ArrayList<>());
        adjacencyList.get(start).add(new Edge(end, weight));
    }

    public List<String> shortestPath(String source, String target) {
        Map<String, Integer> distances = new HashMap<>();
        Map<String, String> previous = new HashMap<>();
        PriorityQueue<Node> queue = new PriorityQueue<>(Comparator.comparingInt(Node::getDistance));

        for (String node : adjacencyList.keySet()) {
            distances.put(node, Integer.MAX_VALUE);
        }
        distances.put(source, 0);
        queue.add(new Node(source, 0));

        while (!queue.isEmpty()) {
            Node current = queue.poll();
            if (current.name.equals(target)) break;

            for (Edge edge : adjacencyList.getOrDefault(current.name, new ArrayList<>())) {
                int newDist = distances.get(current.name) + edge.weight;
                if (newDist < distances.getOrDefault(edge.target, Integer.MAX_VALUE)) {
                    distances.put(edge.target, newDist);
                    previous.put(edge.target, current.name);
                    queue.add(new Node(edge.target, newDist));
                }
            }
        }

        List<String> path = new ArrayList<>();
        String step = target;
        while (step != null) {
            path.add(step);
            step = previous.get(step);
        }
        Collections.reverse(path);

        return distances.get(target) == Integer.MAX_VALUE ? Collections.emptyList() : path;
    }

    private static class Edge {
        String target;
        int weight;

        Edge(String target, int weight) {
            this.target = target;
            this.weight = weight;
        }
    }

    private static class Node {
        String name;
        int distance;

        Node(String name, int distance) {
            this.name = name;
            this.distance = distance;
        }

        public int getDistance() {
            return distance;
        }
    }
}
